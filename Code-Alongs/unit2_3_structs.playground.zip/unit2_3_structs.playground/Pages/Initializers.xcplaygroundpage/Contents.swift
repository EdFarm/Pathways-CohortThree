import Foundation
//: # Initializers
/*:
 - We get "Memberwise" Initializers for "free" with structs
 - We can create our own custom initializers if we need to
 - When you add a custom initializer, you lose the "free" one

 Let's add an initializer that prevents negative values for height and weight
 */
struct Animal {
    // properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters
}

var duma = Animal(name: "Duma", species: "Cheetah", description: "The cheetah is the fastest land animal.", weight: 60, height: 1.5)

var tantor = Animal(name: "Tantor", species: "Elephant", description: "Elephants are the largest land animal.", weight: 5700, height: 3.3)

//: [Previous](@previous) | [Next](@next)
