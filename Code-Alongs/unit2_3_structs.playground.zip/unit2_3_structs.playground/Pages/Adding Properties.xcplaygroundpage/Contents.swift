import Foundation
//: # Adding Properties
/*:
 - What if we want to add more data to our struct?

Let's add height and weight properties
 */
struct Animal {
    // properties
    var name: String
    var species: String
    var description: String
}

var duma = Animal(name: "Duma", species: "Cheetah", description: "The cheetah is the fastest land animal.")

var tantor = Animal(name: "Tantor", species: "Elephant", description: "Elephants are the largest land animal.")

//: [Previous](@previous) | [Next](@next)
