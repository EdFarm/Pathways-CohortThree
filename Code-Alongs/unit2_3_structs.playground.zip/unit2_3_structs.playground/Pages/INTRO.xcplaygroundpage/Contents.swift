//: # Structs
//: ## Unit 2.3
/*:
 - What is a struct?
 - How do we create a struct?
 - Properties
 - Initializers
 - Methods
 - Computed Properties
 - Property Observers
 - Static ("Type") Properties
 */
//: [Next](@next)
