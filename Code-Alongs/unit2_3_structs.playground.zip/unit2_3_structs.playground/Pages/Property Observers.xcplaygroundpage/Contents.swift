import Foundation
//: # Property Observers
/*:
 - Property Observers allow us to watch for changes in our properties
 - Our code can respond to those changes, if needed
 - Validation of data is possible
 - Could also be used to trigger UI updates

 Let's validate the input for weight to prevent it from being set negative.
 */
struct Animal {
    // properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters

    // custom initializer
    init(name: String, species: String, description: String, weight: Double, height: Double) {
        self.name = name
        self.species = species
        self.description = description
        self.weight = weight > 0 ? weight : 0.01 // validate that weight is above zero
        self.height = height > 0 ? height : 0.01 // validate that height is above zero
    }

    // method
    func constructDetails() -> String {
        var results = "All about \(name), the \(species)\n\n"
        results += "Description:\n\t\(description)\n\n"
        results += "Sizes:\n"
        results += "\tHeight: \(height) meters (\(heightInFeet) feet)\n"
        results += "\tWeight: \(weight) kilograms (\(weightInPounds) pounds)\n\n"
        return results
    }

    // mutating method
    mutating func grow() {
        weight += weight / 100.0
        height += height / 100.0
    }

    // computed properties
    var heightInFeet: Double {
        return height * 3.28 // 3.28 feet / meter
    }

    var weightInPounds: Double {
        return weight * 2.2 // 2.2 pounds / kilogram
    }
}

var duma = Animal(name: "Duma", species: "Cheetah", description: "The cheetah is the fastest land animal.", weight: 60, height: 1.5)

var tantor = Animal(name: "Tantor", species: "Elephant", description: "Elephants are the largest land animal.", weight: 5700, height: 3.3)

//: [Previous](@previous) | [Next](@next)
