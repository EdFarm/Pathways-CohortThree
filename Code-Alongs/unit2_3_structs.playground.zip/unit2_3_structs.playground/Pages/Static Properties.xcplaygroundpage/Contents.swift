import Foundation
//: # Static Properties
/*:
 - Static properties and methods are set on the type, and do not change per instance
 - Sometimes called "Type" properties and methods
 - Useful to store data related to the type inside the type itself
 - `static` keyword

 Let's add a static property for fastest land for animals, then add a speed property that is validated against that.
 */
struct Animal {
    // properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double { // kilograms
        willSet {
            print("Preparing to set weight to \(newValue)")
        }
        didSet {
            // if weight is less than zero, reset to the old value
            if weight <= 0 {
                weight = oldValue
            }
        }
    }

    var height: Double // meters

    // custom initializer
    init(name: String, species: String, description: String, weight: Double, height: Double) {
        self.name = name
        self.species = species
        self.description = description
        self.weight = weight > 0 ? weight : 0.01 // validate that weight is above zero
        self.height = height > 0 ? height : 0.01 // validate that height is above zero
    }

    // method
    func constructDetails() -> String {
        var results = "All about \(name), the \(species)\n\n"
        results += "Description:\n\t\(description)\n\n"
        results += "Sizes:\n"
        results += "\tHeight: \(height) meters (\(heightInFeet) feet)\n"
        results += "\tWeight: \(weight) kilograms (\(weightInPounds) pounds)\n\n"
        return results
    }

    // mutating method
    mutating func grow() {
        weight += weight / 100.0
        height += height / 100.0
    }

    // computed properties
    var heightInFeet: Double {
        return height * 3.28 // 3.28 feet / meter
    }

    var weightInPounds: Double {
        return weight * 2.2 // 2.2 pounds / kilogram
    }
}

var duma = Animal(name: "Duma", species: "Cheetah", description: "The cheetah is the fastest land animal.", weight: 60, height: 1.5)

var tantor = Animal(name: "Tantor", species: "Elephant", description: "Elephants are the largest land animal.", weight: 5700, height: 3.3)

//: [Previous](@previous) | [Next](@next)
