import Foundation
//: # Computed Properties
/*:
 - Computed properties allow us to do simple work with our properties and use the results as another property
 - Behavior based on data
 - Slightly more concise than methods

 How could include height in feet and weight in pounds in our detail display?
 */
struct Animal {
    // properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters

    // custom initializer
    init(name: String, species: String, description: String, weight: Double, height: Double) {
        self.name = name
        self.species = species
        self.description = description
        self.weight = weight > 0 ? weight : 0.01 // validate that weight is above zero
        self.height = height > 0 ? height : 0.01 // validate that height is above zero
    }

    // method
    func constructDetails() -> String {
        var results = "All about \(name), the \(species)\n\n"
        results += "Description:\n\t\(description)\n\n"
        results += "Sizes:\n"
        results += "\tHeight: \(height) meters\n"
        results += "\tWeight: \(weight) kilograms\n\n"
        return results
    }

    // mutating method
    mutating func grow() {
        weight += weight / 100.0
        height += height / 100.0
    }
}

var duma = Animal(name: "Duma", species: "Cheetah", description: "The cheetah is the fastest land animal.", weight: 60, height: 1.5)

var tantor = Animal(name: "Tantor", species: "Elephant", description: "Elephants are the largest land animal.", weight: 5700, height: 3.3)

//: [Previous](@previous) | [Next](@next)
