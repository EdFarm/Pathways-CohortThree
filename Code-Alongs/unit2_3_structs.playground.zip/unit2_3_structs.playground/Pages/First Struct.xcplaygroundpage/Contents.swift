import Foundation
//: # Our first struct!
/*:
 - Custom Types
 - Useful as we model the world for our app
 - Data AND Behavior
 - Data = Properties
 */
struct Animal {
    var name: String
    var species: String
    var description: String
}
//: Let's create a few animal instances here...

//: [Previous](@previous) | [Next](@next)
