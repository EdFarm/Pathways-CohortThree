//: ## While Loops Example
/*:
 - What if we wanted to keep checking for a change? 
 */
var counter = 1
var userTaps = 0
var goalTaps = 10

func fakeUserTap() {
    let randomInt = Int.random(in: 1...100)
    if randomInt > 90 {
        userTaps += 1
    }
}

while userTaps < goalTaps {
    fakeUserTap()
    counter += 1
}

print("It took \(counter) loops to get \(goalTaps) taps!")
//: [Previous](@previous) | [Next](@next)


import Foundation
