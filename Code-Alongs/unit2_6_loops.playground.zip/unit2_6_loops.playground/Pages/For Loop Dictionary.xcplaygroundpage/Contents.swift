//: ## For Loop with Dictionaries
/*:
 - For loops also work with dictionaries
 - Instead of just the index, you get the `key` and `value` to use
 */
var contacts = ["Janet": "111-111-1111", "Bill": "222-333-4444", "Rosie": "205-867-5309"]

// for (key, value) in dictionary...
for (name, phone) in contacts {
  print("\(name)'s phone number is: \(phone)")
}
//: [Previous](@previous) | [Next](@next)
import Foundation
