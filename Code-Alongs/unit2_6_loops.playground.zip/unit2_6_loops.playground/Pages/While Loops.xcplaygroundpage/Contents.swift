//: ## While Loops
/*:
 - While loops run while a conditional statement is `true`
 - Remember to iterate the counter to avoid endless loops!
 */
var counter = 0

// while conditional is true...
while counter >= -15 {
    // do something awesome here
    print(counter)
    counter -= 1 // MAKE SURE to update values used by conditional at some point!
}

print("all done!")
//: [Previous](@previous) | [Next](@next)


import Foundation
