//: ## Enumerated Strings
/*:
 */
let word = "Candy Catapult"

// use the .enumerated() method on a string to get (index, letter) tuple
for (index, letter) in word.enumerated() {
  print("\(index) is \(letter)")
}

// can also enumerate values in an array to get the index!
let sentence = "Hello there Pathways how are you tonight?"
let words = sentence.split(separator: " ")

for (index, word) in words.enumerated() {
    if (index == words.count - 1) {
        print("Last word is: \(word)")
    } else {
        print("Word at \(index): \(word)")
    }
}
//: [Previous](@previous) | [Next](@next)


import Foundation
