import Foundation

public func fizzBuzz(_ testValue: Int) -> String {
    let dividesByThree = testValue % 3 == 0
    let dividesByFive = testValue % 5 == 0

    if (dividesByThree && dividesByFive) {
        return "fizzbuzz"
    } else if (dividesByThree) {
        return "fizz"
    } else if (dividesByFive) {
        return "buzz"
    }
    return "\(testValue)"
}
