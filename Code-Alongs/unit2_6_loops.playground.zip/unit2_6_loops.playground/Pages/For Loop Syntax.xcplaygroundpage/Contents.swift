//: ## For Loop Syntax
/*:
 - Loops run repeatedly
 - For loops run once for each item in a range
 */
import Foundation
//: the way we used fizzbuzz previously...
fizzBuzz(1)
fizzBuzz(2)
fizzBuzz(3)
fizzBuzz(4)
fizzBuzz(5)
fizzBuzz(6)
fizzBuzz(7)
fizzBuzz(8)
fizzBuzz(9)
fizzBuzz(10)
fizzBuzz(11)
fizzBuzz(12)
fizzBuzz(13)
fizzBuzz(14)
fizzBuzz(15)
//: loops to the rescue!
for number in 1...15 {
    let results = fizzBuzz(number)
    print("Results for \(number): \(results)")
}
//: what if we just want to do something 5 times?
for _ in 1...5 {  // No value needed, so we can use `_`
    print("Hello, is this annoying yet?")
    sleep(2)
}

//: [Previous](@previous) | [Next](@next)
