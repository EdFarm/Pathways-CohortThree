//: ## For Loop with Arrays
/*:
 - For loops can also be used with collections
 - The loop is run once per item in the collection
 */
let sentence = "Hello there Pathways how are you tonight?"

// Let's use a helpful method to split a String into an Array!
let words = sentence.split(separator: " ")

// our `words` constant now looks like the array on the next line!
//let words = ["Hello", "there", "Pathways", "how", "are", "you", "tonight?"]

print(words)
print("There are \(words.count) words in our sentence!")


for word in words {
    print(word.uppercased())
}
//: [Previous](@previous) | [Next](@next)


import Foundation
