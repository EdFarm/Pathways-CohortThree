struct VIP {
    var firstName: String
    var lastName: String

    var displayName: String {
        return "\(firstName) \(lastName)"
    }

    // simple print method
    func greet() {
        print("Hello, \(displayName)!")
    }
}

var taylorSwift = VIP(firstName: "Taylor", lastName: "Swift")

taylorSwift.greet()
//: What if the VIP doesn't use a last name?
var prince = VIP(firstName: "Prince", lastName: "")

prince.greet()
//: Another example
var pink = VIP(firstName: "P!nk", lastName: "")

pink.greet()
//: [Previous](@previous) | [Next](@next)
