import Foundation
//: Back to our VIP example...
struct VIP {
    var firstName: String
    var lastName: String? // optional property

    //: `if let` optional binding
    var displayName: String {
        if let lastName = lastName {
            return "\(firstName) \(lastName)"
        } else {
            return firstName
        }
    }

    // simple print method
    func greet() {
        print("Hello, \(displayName)!")
    }
}

var taylorSwift = VIP(firstName: "Taylor", lastName: "Swift")

taylorSwift.greet()
//: If nil, no need to include property in intializer
var prince = VIP(firstName: "Prince")

prince.greet()
//: Another example
var pink = VIP(firstName: "P!nk")

pink.greet()
