
/*
 Intro
 Why Optionals?
 nil
 Optional type annotation
 Unwrapping Optionals
 Optional Binding
 Using Optionals
 Failable Initializers
 Optional Chaining
 Example: Dictionary Values
 */
