import Foundation
//: What if we had a better way to use optional values?
let aString: String? = "I'm a String!"

let notAString: String? = nil

var notYetAString: String? // also nil
//: `if let` syntax
print(aString)
if let bString = aString {
    print(bString)
}
//: Typical use ("shadowing" name)
if let aString = aString {
    print(aString.count)
}
//: `if let else` syntax is also an option
if let notAString = notAString {
    // if binding works...
    print(notAString)
} else {
    // otherwise...
    print("That's no String, it's NIL!")
}
