//: ## Failable Initializers
struct VIP {
    var firstName: String
    var lastName: String? // optional property

    init?(firstName: String, lastName: String?) {
        if firstName.isEmpty {
            return nil
        }
        self.firstName = firstName
        self.lastName = lastName
    }

    //: `if let` optional binding
    var displayName: String {
        if let lastName = lastName {
            return "\(firstName) \(lastName)"
        } else {
            return firstName
        }
    }

    // simple print method
    func greet() {
        print("Hello, \(displayName)!")
    }
}
