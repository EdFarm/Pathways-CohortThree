import Foundation

let fibonacciArray = [1, 2, 3, 5, 8, 13, 21]

var checkValue = 8
// check out the documentation for `firstIndex` here
if let realNum = fibonacciArray.firstIndex(of: checkValue) {
  print(realNum)
} else {
    print("\(checkValue) not found in array")
}

let phoneDictionary = ["Bill": "111-222-3333", "Janet": "205-000-0000", "Steve": "111-867-5309"]

// what happens if we try and lookup a value in a dictionary?

print(phoneDictionary["Bill"])

print(phoneDictionary["John"])
