//: ## nil
/*:
 - The absence of any value
 - Empty
 - Nothing
 - Nada
 - Zilch
 */
//: [Previous](@previous) | [Next](@next)

