// nested optional example...
// user/address/unit number

struct User {
    var email: String
    var address: Address?
}

struct Address {
    var street: String
    var unit: String?
    var city: String
    var state: String
    var postalCode: String
}

let addr1 = Address(street: "123 Main St", unit: nil, city: "Birmingham", state: "AL", postalCode: "35209")

let user1 = User(email: "test@example.com", address: addr1)

// ?? means "If nil, do/use this"
print(user1.address?.unit?.count ?? 0)

/*
user1.address?.unit?.count ?? 0
=============?=====?========> .count
              \     \
               \     \
                ============> 0
*/

