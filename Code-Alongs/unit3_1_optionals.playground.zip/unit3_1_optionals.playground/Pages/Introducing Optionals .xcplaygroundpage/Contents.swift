import Foundation

var maybeString: String? = "hello, pathways!"

print(maybeString)
print(maybeString.count)
//: We can `Force Unwrap` and optional using `!`
print(maybeString!)
print(maybeString!.count)
//: if we update the value to nil...
maybeString = nil
//: what if we try to unwrap it now?
print(maybeString!) // OH NO!
//: [Previous](@previous) | [Next](@next)
