import UIKit
import PlaygroundSupport
// data URL = https://zoo.tiki.dev/index.json
// use this to allow for long running tasks
PlaygroundPage.current.needsIndefiniteExecution = true

let baseURL = "https://zoo.tiki.dev"
let url = URL(string: "\(baseURL)/index.json")!

let request = URLSession.shared.dataTask(with: url) { (data, response, error) in
    let jsonDecoder = JSONDecoder()
    if let data = data,
       let dataString = String(data: data, encoding: .utf8),
       let animals = try? jsonDecoder.decode([Animal].self, from: data) {
        // send notification with animal info...
        print(dataString)
        for animal in animals {
            print(animal)
        }
    }
    // handle the error...
    // use response values for other requests...

    PlaygroundPage.current.finishExecution()
}

request.resume()

struct Animal: CustomStringConvertible, Codable {
    var name: String
    var species: String
    var height: Double
    var weight: Double
    var area: String
    var facts: String
    var image: String

    var description: String {
        return "\(name) is a \(species)\nHeight: \(height) m, Weight: \(weight) kg\nArea: \(area)\nFun Facts: \(facts)\nImage: \(image).\n\n"
    }

    enum CodingKeys: String, CodingKey {
        case name, species, height
        case weight
        case area
        case facts = "funFacts" // note the difference between the string and enum case
        case image = "image_url"
    }
}

