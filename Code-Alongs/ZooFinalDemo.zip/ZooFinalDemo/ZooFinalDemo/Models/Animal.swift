//
//  Animal.swift
//  ZooFinalDemo
//
//  Created by Taylor Smith on 4/21/21.
//

import Foundation

struct Animal {
    var name: String
    var species: String
    var height: Double
    var weight: Double
    var area: String
    var facts: String
    var image: String
}

extension Animal: CustomStringConvertible {
    var description: String {
        return "\(name) is a \(species)\n\nSizes:\nHeight: \(height) m, Weight: \(weight) kg\n\nArea: \(area)\n\nFun Facts: \(facts)\n"
    }
}

extension Animal: Codable {
    enum CodingKeys: String, CodingKey {
        case name, species, height
        case weight
        case area
        case facts = "funFacts" // note the difference between the string and enum case
        case image = "image_url"
    }
}
