//
//  AnimalCollectionViewCell.swift
//  ZooFinalDemo
//
//  Created by Taylor Smith on 4/22/21.
//

import UIKit

class AnimalCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var animalImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var speciesLabel: UILabel!
    @IBOutlet weak var areaLabel: UILabel!

    func update(with animal: Animal) {
        animalImageView.sd_setImage(with: URL(string: animal.image), placeholderImage: UIImage(named: "loading"))
        nameLabel.text = animal.name
        speciesLabel.text = animal.species
        areaLabel.text = animal.area
    }
}
