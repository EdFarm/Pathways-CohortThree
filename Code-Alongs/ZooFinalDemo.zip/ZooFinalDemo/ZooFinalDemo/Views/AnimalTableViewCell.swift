//
//  AnimalTableViewCell.swift
//  ZooFinalDemo
//
//  Created by Taylor Smith on 4/21/21.
//

import UIKit
import SDWebImage

class AnimalTableViewCell: UITableViewCell {
    @IBOutlet weak var animalImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var speciesLabel: UILabel!
    @IBOutlet weak var areaLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    func update(with animal: Animal) {
        animalImageView.sd_setImage(with: URL(string: animal.image), placeholderImage: UIImage(named: "loading"))
        nameLabel.text = animal.name
        speciesLabel.text = animal.species
        areaLabel.text = animal.area
    }

}
