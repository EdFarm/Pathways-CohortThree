//
//  NetworkController.swift
//  ZooFinalDemo
//
//  Created by Taylor Smith on 4/21/21.
//
import Foundation

let baseURL = "https://zoo.tiki.dev"

struct NetworkController {
    func fetchAnimalList(completionHandler: @escaping ([Animal]) -> Void) {
        let animalURL = "\(baseURL)/index.json"
        let requestURL = URL(string: animalURL)!

        let request = URLSession.shared.dataTask(with: requestURL) { (data, response, error) in
            if let error = error {
                print(error)
                return
            }

            guard let data = data else {
                print("No data!")
                return
            }

            let jsonDecoder = JSONDecoder()
            if let results = try? jsonDecoder.decode([Animal].self, from: data) {
                completionHandler(results)
            }
        }

        request.resume()
    }
}
