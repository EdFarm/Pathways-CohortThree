//
//  DetailViewController.swift
//  ZooFinalDemo
//
//  Created by Taylor Smith on 4/21/21.
//

import UIKit

class DetailViewController: UIViewController {
    var animal: Animal?

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var speciesLabel: UILabel!
    @IBOutlet weak var areaLabel: UILabel!
    @IBOutlet weak var detailTextView: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()
        if let animal = animal {
            loadContent(with: animal)
        }
    }

    func loadContent(with animal: Animal) {
        title = animal.name
        imageView.sd_setImage(with: URL(string: animal.image), placeholderImage: UIImage(named: "loading"))
        speciesLabel.text = animal.species
        areaLabel.text = animal.area
        detailTextView.text = animal.description
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
