//
//  AnimalCollectionViewController.swift
//  ZooFinalDemo
//
//  Created by Taylor Smith on 4/22/21.
//

import UIKit

class AnimalCollectionViewController: UIViewController {
    let animalDetailSegueIdentifier = "AnimalCollectionDetailSegue"

    var animals: [Animal] = [] {
        didSet {
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        }
    }

    let networkController: NetworkController = NetworkController()

    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        networkController.fetchAnimalList { (animals) in
            self.animals = animals
        }
    }
}

extension AnimalCollectionViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        animals.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AnimalCollectionCell", for: indexPath) as! AnimalCollectionViewCell
        let animal = animals[indexPath.row]

        cell.update(with: animal)
        return cell
    }
}

extension AnimalCollectionViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let animal = animals[indexPath.row]

        performSegue(withIdentifier: animalDetailSegueIdentifier, sender: animal)
        collectionView.deselectItem(at: indexPath, animated: true)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == animalDetailSegueIdentifier {
            guard let destination = segue.destination as? DetailViewController,
                  let sender = sender as? Animal else {
                return
            }

            destination.animal = sender
        }
    }
}
