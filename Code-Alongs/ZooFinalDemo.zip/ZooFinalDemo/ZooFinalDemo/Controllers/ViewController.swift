//
//  ViewController.swift
//  ZooFinalDemo
//
//  Created by Taylor Smith on 4/21/21.
//

import UIKit

class ViewController: UIViewController {
    let animalDetailSegueIdentifier = "AnimalDetailSegue"

    var animals: [Animal] = [] {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }

    let networkController: NetworkController = NetworkController()

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        networkController.fetchAnimalList { (animals) in
            self.animals = animals
        }
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        animals.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AnimalTableViewCell") as! AnimalTableViewCell

        let animal = animals[indexPath.row]
        if animal.area.isEmpty && animal.name.isEmpty && animal.species.isEmpty {
            print("UH OH!")
        }
        cell.update(with: animal)

        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let animal = animals[indexPath.row]

        performSegue(withIdentifier: animalDetailSegueIdentifier, sender: animal)
        tableView.deselectRow(at: indexPath, animated: true)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == animalDetailSegueIdentifier {
            guard let destination = segue.destination as? DetailViewController,
                  let sender = sender as? Animal else {
                return
            }

            destination.animal = sender
        }
    }
}

