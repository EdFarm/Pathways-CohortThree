//
//  Constants.swift
//  ZooFinalDemo
//
//  Created by Taylor Smith on 4/21/21.
//

import Foundation

let baseURL = "https://zoo.tiki.dev"
