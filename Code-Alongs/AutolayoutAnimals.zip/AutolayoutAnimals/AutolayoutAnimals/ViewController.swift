//
//  ViewController.swift
//  AutolayoutAnimals
//
//  Created by Taylor Smith on 3/15/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

