import Foundation

import Foundation

public class Animal {
    public var name: String
    public var height: Double
    public var weight: Double

    public init(name: String, height: Double, weight: Double) {
        self.name = name
        self.height = height
        self.weight = weight
    }

    public var facts: String {
        return "Special information about the animal goes here."
    }

    public func fullDescription() -> String {
        var details = "All about \(name)\n\n"
        details += "Fun Fact: \(facts)\n\n"
        details += "Sizes:\n"
        details += "\tHeight: \(height) meters\n"
        details += "\tWeight: \(weight) kilograms\n"
        return details
    }
}

public class Elephant: Animal {
    public override var facts: String {
        return "The elephant is the largest land animal."
    }
}

public class Macaw: Animal {
    public init(name: String, height: Double, weight: Double, flyingSpeed: Double) {
        self.flyingSpeed = flyingSpeed
        super.init(name: name, height: height, weight: weight)
    }

    public var flyingSpeed: Double

    public override var facts: String {
        return "The macaw can live up to 60 years old."
    }
}

public class Cheetah: Animal {
    public override var facts: String {
        return "The cheetah is the fastest land animal."
    }
}

public let blu = Macaw(name: "Blu", height: 0.8, weight: 1.2, flyingSpeed: 22)
public let tantor = Elephant(name: "Tantor", height: 3.4, weight: 5200)
public let duma = Cheetah(name: "Duma", height: 1.2, weight: 75)

// Array of different subclasses of animals
public let animals: [Animal] = [blu, tantor, duma]
