import Foundation
//: ## Guard
/*:
 - Callout(What if...): We could make things simpler to read?
 */
let day = "Tuesday"
let studentsPresent = 15
let computerSetUp = true
//: New keyword: `guard`\
//: Find the Happy Path below
func teachSwift() {
    guard day == "Tuesday" || day == "Thursday" else {
        print("No class tonight!")
        return
    }
    
    guard studentsPresent > 0 else {
        print("No students present!")
        return
    }
    
    guard computerSetUp else {
        print("Set up the computer!")
        return
    }
    
    print("Let's learn some Swift!")
    // do whatever else we want to do!
}

teachSwift()
//: [Previous](@previous) | [Next](@next)
