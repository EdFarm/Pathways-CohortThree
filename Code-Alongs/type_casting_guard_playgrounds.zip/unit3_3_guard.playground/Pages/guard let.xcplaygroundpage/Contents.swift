import Foundation
//: ## Guard Let
var animalNameDictionary: [String: Animal] = [:]

for animal in animals {
    animalNameDictionary[animal.name] = animal
}
// result: ["Blu": blu, "Duma": duma, "Tantor": tantor]
//: New keyword set: `guard let`
func animalDescriptionByName(_ name: String) -> String? {
    guard let animal = animalNameDictionary[name] else {
        return nil // bail out!
    }
    
    return animal.fullDescription() // happy path
}

if let description = animalDescriptionByName("Duma") {
    print(description)
} else {
    print("Error: No animal found by that name.")
}
//: [Previous](@previous) | [Next](@next)
