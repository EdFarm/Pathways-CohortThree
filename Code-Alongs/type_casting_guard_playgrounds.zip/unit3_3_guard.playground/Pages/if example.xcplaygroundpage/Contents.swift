import Foundation
//: ## Happy/Sad Path
let day = "Tuesday"
let studentsPresent = 15
let computerSetUp = true
//: Exercise: Find the Happy Path below
func teachSwift() {
    if day == "Tuesday" || day == "Thursday" {
        if studentsPresent > 0 {
            if computerSetUp {
                print("Let's learn some Swift!")
            } else {
                print("Set up the computer!")
                return
            }
        } else {
            print("No students present!")
            return
        }
    } else {
        print("No class tonight!")
        return
    }
    // do whatever else we want to do!
}

teachSwift()
//: [Previous](@previous) | [Next](@next)
