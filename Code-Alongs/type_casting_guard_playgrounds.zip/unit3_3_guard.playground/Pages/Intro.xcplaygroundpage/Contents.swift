//: ## Guard
/*:
 - `guard`
 - `guard let`
 - Happy Path
 - Sad Path
 */
//: [Next](@next)
