import Foundation
//: ## How can we use this?
/*:
 - Just start using it! It's useful as another control flow option anywhere you might use an if statement.
 - Remember to think of the happy and sad paths in your code. Find ways to make it clearer to the next person which paths are which in your flow.
 - Use `guard` before entering a loop to stop your function before it gets there, if needed. Loops are where your code will most likely get slow, and if you don't need to do that work, don't!
 - Figure out your own code style in terms of if/guard statements and how you like to solve the problems in your code. If it works, it's good!
 */

//: [Previous](@previous)
