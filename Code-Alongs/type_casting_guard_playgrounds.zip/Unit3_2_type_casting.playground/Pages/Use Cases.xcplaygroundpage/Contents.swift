//: ## How can we use this?
/*:
 - UIKit will often send fairly generic superclass types to methods that you will need to typecase or inspect to fully take advantage of. Segues are a common case that we'll look at soon.
 */
/*:
 - In our example today, when we used the superclass of "Animal" we were able to take advantage of all of the "animal-ness" of our data, and could utilize the species-level data when we needed to. This is a common pattern to take advantage of the class hierarchy while also keeping the data manageable. An array for every subclass of Animal would likely be overkill for our use, for example.
 */
//: ## Questions?
//: [Previous](@previous)
