//: ## Type Casting and Inspection
/*:
 - Animal class hierarchy
 - Type Inspection
 - Type Casting
 - `Any` Type
 - Common Use Cases
 */
//: [Next](@next)
