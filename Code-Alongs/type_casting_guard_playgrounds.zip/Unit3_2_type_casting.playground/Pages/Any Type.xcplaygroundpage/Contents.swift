import Foundation
//: ## Any
let anyArray: [Any] = [1, 2.3, "Hello Pathways", false]
//: What if we want to try and use these as something other than `Any`?
if let item = anyArray.first as? Int {
    print("Doing integer sum()")
    print(sum(item, 12))
}

func sum(_ a: Int, _ b: Int) -> Int {
    return a + b
}
//: [Previous](@previous) | [Next](@next)
