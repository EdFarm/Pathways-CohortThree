import Foundation
//: ## Type Inspection
//: New keyword: `is`
if animals.first is Animal {
    print("WE'VE GOT AN ANIMAL!")
}

for animal in animals {
    if animal is Cheetah {
        print("\(animal.name) is a cheetah!")
        // do something cheetah specific...
    } else if animal is Elephant {
        print("\(animal.name) is an elephant!")
        // do something elephant specific...
    } else if animal is Macaw {
        print("\(animal.name) is a macaw!")
        // do something macaw specific...
    }
    print(animal.fullDescription())
    print("=====    \n")
}
//: [Previous](@previous) | [Next](@next)
