import Foundation
//: ## Type Casting
//: Another new keyword: `as`
// Why won't this work?
print(animals[0].flyingSpeed)

// we can force downcast something...
var cheetah = animals.last as! Cheetah

// but BEWARE...
var elephant = animals.first as! String

// we can also conditonally cast something...
if let bird = animals.last as? Macaw {
    print(bird.flyingSpeed)
} else {
    print("NOT A MACAW!")
}
//: [Previous](@previous) | [Next](@next)
