import Foundation
//: ## Animals
class Animal {
    var name: String
    var height: Double
    var weight: Double

    init(name: String, height: Double, weight: Double) {
        self.name = name
        self.height = height
        self.weight = weight
    }

    var facts: String {
        return "Special information about the animal goes here."
    }

    func fullDescription() -> String {
        var details = "All about \(name)\n\n"
        details += "Fun Fact: \(facts)\n\n"
        details += "Sizes:\n"
        details += "\tHeight: \(height) meters\n"
        details += "\tWeight: \(weight) kilograms\n"
        return details
    }
}

class Cheetah: Animal {
    override var facts: String {
        return "The cheetah is the fastest land animal."
    }
}

class Elephant: Animal {
    override var facts: String {
        return "The elephant is the largest land animal."
    }
}

class Macaw: Animal {
    init(name: String, height: Double, weight: Double, flyingSpeed: Double) {
        self.flyingSpeed = flyingSpeed
        super.init(name: name, height: height, weight: weight)
    }

    var flyingSpeed: Double

    override var facts: String {
        return "The macaw can live up to 60 years old."
    }
}

let blu = Macaw(name: "Blu", height: 0.8, weight: 1.2, flyingSpeed: 22)
let tantor = Elephant(name: "Tantor", height: 3.4, weight: 5200)
let duma = Cheetah(name: "Duma", height: 1.2, weight: 75)

// Array of different subclasses of animals
let animals: [Animal] = [blu, tantor, duma]
//: [Previous](@previous) | [Next](@next)
