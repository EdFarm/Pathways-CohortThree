//: ## Function Design
/*:
- Swift allows us to make a few decisions about the style our functions have
 - Some of these impact the way the functions work, others are more about code style
 - External parameter naming, omitting labels, and default values are all part of this
 - Swift allows for omitting the `return` keyword in single line functions that return values
 */
/// notice `to recipient`
/// external and internal parameter names
func sendMessage(to recipient: String) {
    print("Hi, \(recipient)")
}
sendMessage(to: "Taylor")




/// notice the `_` for the external parameter name
/// this allows that parameter to be used without a name, which can help readability
func sayHelloTo(_ className: String) {
    print("Hello \(className)")
}
sayHelloTo("Pathways")





func precipitationChance(morningChance morning: Double, afternoonChance afternoon: Double) -> Double {
    // get the average of the sample that there will precipitation
    let numberOfSamples: Double = 2
    let averageChance = (morning + afternoon) / numberOfSamples
    return averageChance;
}

let chance = precipitationChance(morningChance: 0.5, afternoonChance: 0.9)
print(chance)







func weatherReport(highTemperature: Int, lowTemperature: Int, weatherDescription: String = "sunny") -> String {
    return "Today's weather will be \(weatherDescription) with a high of \(highTemperature) degress and a low of \(lowTemperature) degrees!"
}

/// this method only prints the results of `weatherReport`, but at times something simple like that is useful
func reportWeather(highTemperature: Int, lowTemperature: Int, weatherDescription: String = "sunny") {
    print(weatherReport(highTemperature: highTemperature, lowTemperature: lowTemperature, weatherDescription: weatherDescription))
}

reportWeather(highTemperature: 81, lowTemperature: 65, weatherDescription: "rainy")

print(weatherReport(highTemperature: 45, lowTemperature: 30))
//: [Previous](@previous) | [Next](@next)
