//: ## Title
/*:
 - Callout(Callout): text
 */
// code here
//: [Previous](@previous) | [Next](@next)


/*:
 - Callout(Practice): Try this out!\
Give this exercise a try to improve your skills.
 */

import Foundation
