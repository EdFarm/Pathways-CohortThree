//: ## Returning Values
//: ### Data In, Data Out
/*:
- Functions are able to `return` a value to us as a result of the execution of the function
 - The type of the return value is specified in the function definition
 */
//: Let's assume we have two samples indicating daily chance of precipation and want to show the user the average of those two...

func weatherReport(highTemperature: Int, lowTemperature: Int, weatherDescription: String = "sunny") -> String {
    return "Today's weather will be \(weatherDescription) with a high of \(highTemperature) degress and a low of \(lowTemperature) degrees!"
}

let icyWeather = weatherReport(highTemperature: -1, lowTemperature: -12, weatherDescription: "icy")
let sunnyWeather = weatherReport(highTemperature: 80, lowTemperature: 60)

print(icyWeather)
print(sunnyWeather)



// another example...
func precipitationChance(morningChance: Double, afternoonChance: Double) -> Double {
    // get the average of the "chances" that there will precipitation
    let numberOfSamples = 2
    let averageChance = (morningChance + afternoonChance) / Double(numberOfSamples)
    return averageChance
}

/*:
 - Callout(Practice): Use the `precipitationChance` function above to get the average chance of precipitation if you have a `morningChance` of 0.5 and and `afternoonChance` of 0.25. Store the result in a constant and print that constant.
 */
//: [Previous](@previous) | [Next](@next)
