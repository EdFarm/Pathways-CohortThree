//: ## Defining Functions
//: ### What the `func`
/*:
 Look at `exampleFunction` below
 - Note the `func` keyword
 - Parentheses `()` are used to hold the parameters
 - An arrow `->` points to the return type, if the function returns data
 - Just like our `if-else` expressions, the block of code that is executed is contained in curly braces `{}`
 */
// the basics
func simpleFunction() {
    // do work here...
    print("I don't do much, but I do it well!")
}

// this function has parameters available to work with
func parameterFunction(parameter1: String, parameter2: Int) {
    // do other work here...
    print("I use my parameters, parameter1: \(parameter1) and parameter2: \(parameter2), to do work!")
}

// this function provides a value as a result of doing its work
func exampleFunction(aStringParameter: String) -> Bool {
    return aStringParameter.count > 10
}

// as an example
func reportWeather() {
    print("Today's weather will be sunny with a high of 72 degress and a low of 55 degrees!")
}

reportWeather()
//: this is probably pretty boring unless we live in San Diego... we'll need to change that String with some data...

//: [Previous](@previous) | [Next](@next)


import Foundation
