//: # Functions
//: ## Unit 2.2
/*:
 - What is a function?
 - How do we write a function?
 - Parameters going into your functions
 - Returning values coming out of your functions
 */
//: [Next](@next)
