//: ## Concatenation
//: ### A big way to say "Add"
/*:
- One way we can put multiple strings together is with **concatenation**
 - Looks like addition of strings, and functions about like that
 */
let title = "10 Reasons You Should Read This Article!"
let author = "Estella Kaye"

// sometimes having the first and last name split is useful...
let authorFirstName = "Estella"
let authorLastName = "Kaye"

let authorFullName = authorFirstName + " " + authorLastName
print(authorFullName)

// you can also use compound assignment with concatenation
var combined = title
combined += " By: "
combined += authorFullName

print(combined)
//: [Previous](@previous) | [Next](@next)
