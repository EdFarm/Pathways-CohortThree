//: ## Looking Inside Strings
/*:
 - Sometimes we need to check on what's inside a string
 - There are several properties and methods we have available to help with that
 */
import Foundation

let emptyString = ""
let title = "Taylor Swift Learns to Program in Swift"

print("Empty String Stats:")
print(emptyString.isEmpty)
print(emptyString.count)

//print("Title String Stats:")
//print(title.isEmpty)

if (title.hasPrefix("Taylor Swift")) {
    print("found another article!")
    // do whatever else!
}

if (title.hasSuffix("Swift")) {
    print("another Swift article found!")
    // do something after matching suffix
}

// does our string contain the string "earns"?
if (title.contains("earns")) {
    print("found a matching string!")
    // do something if it matches...
}

/*:
 - Callout(Practice): Print out the count of characters in the `title` String from above.\
 \
Create a `keyword` constant. Using an if-else statement, determine if `title` contains `keyword`, and print a message indicating whether `keyword` was found or not (hint: if-else). Be sure to include `keyword` in the printed message (hint: interpolation).
 */
//: [Previous](@previous) | [Next](@next)
