//: ## Characters
//: ### The pieces of String
/*:
- Strings can be represented in many ways, including as a collection of another type - Character
 - Characters contain a single Unicode character
 */

let oneLetter = "K" // Swift infers type to be String
let oneCharacter: Character = "T"
let emojiCharacter: Character = "😎"
//: [Previous](@previous) | [Next](@next)
