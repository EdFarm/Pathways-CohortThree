//: ## String Comparison and Equality
/*:
- Strings can be compared using some of comparison operators we've become familiar with
 - `==` looks for identical characters in the same order.
 - Strings ARE case sensitive when comparing
*/
let author = "Arthur Lynette"
let anotherAuthor = "Serena Raymond"
//: are these the same?
print(author == anotherAuthor)
//: what about lowercase comparisons?
let lowercaseAuthor = "arthur lynette"
print(author == lowercaseAuthor)

/*: Adjusting the case can be useful for comparisons at times. Imagine we've got a login form where we accept an email address.
 */
let databaseEmail = "tEst@examPle.com"
let enteredEmail = "Test@exAmple.com"

print(databaseEmail.uppercased() == enteredEmail.uppercased())
//: [Previous](@previous) | [Next](@next)
