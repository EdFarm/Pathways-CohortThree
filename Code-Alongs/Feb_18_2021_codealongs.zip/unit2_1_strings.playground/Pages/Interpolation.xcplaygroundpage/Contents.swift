//: ## Interpolation
//: ### Combining values inline
/*:
- Another way we can combine strings is with **interpolation**
 - Special syntax, other languages have their own syntax to handle interpolation
*/
let title = "10 Reasons You Should Read This Article!"
let author = "Estella Kaye"
let authorFirstName = "Estella"
let authorLastName = "Kaye"

var fullName = authorFirstName
fullName += " \(authorLastName)"

let combined = "\(title) By: \(author)"
print(combined)

// we can even combine types here!
let numberString = "Hey look numbers! \(1+3) \(8/2)"
print(numberString)

/* Practice
 - instantiate a String constant with the name of the current month as its value
 - instantiate 2 Int constants, one with the number value of today's date, and one with the current year
 - use interpolation to print a message that includes the full date.
 - Example: "Today is July 4, 2021"
*/
//: [Previous](@previous) | [Next](@next)
