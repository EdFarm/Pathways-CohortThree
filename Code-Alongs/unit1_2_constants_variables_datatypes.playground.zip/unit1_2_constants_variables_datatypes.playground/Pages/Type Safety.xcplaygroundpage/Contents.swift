//: ## Type Safety
/*:
 - Once the type of an instance is set in Swift, it cannot be changed
 */
let numberOfAnimals = 53

var priceOfTicket = 12.95

let swiftIsAwesome = true

let name = "Taylor Smith"

numberOfAnimals = "hello"

priceOfTicket = numberOfAnimals
//: [Previous](@previous) | [Next](@next)
