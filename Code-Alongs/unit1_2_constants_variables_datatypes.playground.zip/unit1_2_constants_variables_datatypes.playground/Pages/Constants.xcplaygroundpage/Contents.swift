//: ## Constants
/*:
 - Constants CANNOT be changed after being initialized.
 - Read aloud as "let firstName equal Taylor"
 */
/*:
 - Callout(Keyword!): `let`
 */
let firstName = "Taylor"
let cohort = 3
let currentYear = 2021
let meetingInPerson = false

print(firstName)
//: [Previous](@previous) | [Next](@next)


import Foundation
