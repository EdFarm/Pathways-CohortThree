//: ## Type Annotation
/*:
- We can explicitly label our values with their type
 - Syntax is `name: Type` as shown below
 - Typically not required!
 */
let numberOfAnimals: Int = 53

var priceOfTicket: Double = 12.95

// what types are these? Let's add annotations...
let swiftIsAwesome = true

let name = "Taylor Smith"
//: [Previous](@previous) | [Next](@next)
