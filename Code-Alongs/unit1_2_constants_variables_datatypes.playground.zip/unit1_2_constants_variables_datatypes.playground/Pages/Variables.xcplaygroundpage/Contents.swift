//: ## Variables
/*:
 - Variables CAN be changed after being initialized.
 - Read aloud as "set variable currentSong to Baby Shark"
 */
/*:
 - Callout(Keyword!): `var`
 */
// at least it's a variable and we can change it!
var currentSong = "Baby Shark"

var nextSong = "Shake it Off"

print(currentSong)

// update the value of current song (PLEASE!)
currentSong = nextSong

print(currentSong)

//: [Previous](@previous) | [Next](@next)


import Foundation
