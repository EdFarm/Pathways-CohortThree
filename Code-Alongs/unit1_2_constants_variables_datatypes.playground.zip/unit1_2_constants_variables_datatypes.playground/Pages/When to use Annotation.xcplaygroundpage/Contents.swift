//: ## When is annotation useful?
//: ### A few cases
// when you haven't assigned a value yet
let firstName: String

// when you need to clarify type ambiguity
// numberOfTickets inferred to be an Integer
// type annotation clarifies ambiguity
let priceOfTicket = 12.95
var numberOfTickets = 321
let dailyTicketSales = numberOfTickets * priceOfTicket // fix with annotations above!

// when adding properties to a type definition
struct Cohort {
    let number: Int
    let year: Int
    let season: String

    func welcome() {
        print("Welcome to the Cohort \(number) of Ed Farm's Pathways, taking place during the \(season) of \(year)!")
    }
}
//: [Previous](@previous) | [Next](@next)
