//: ## Group Discussion
//: ### When should you use constants or variables?
/*:
- We're going to build an app for a zoo to list animals and other information.
 - What data do we need?
 - What should be constant and what should be variable?
*/
// variables and constants go HERE

//: [Previous](@previous) | [Next](@next)


import Foundation
