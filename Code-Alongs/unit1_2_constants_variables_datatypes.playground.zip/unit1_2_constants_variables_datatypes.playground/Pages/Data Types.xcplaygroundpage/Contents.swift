//: ## Types
//: ### Data and Behavior Combined
struct Cohort {
    let number: Int
    let year: Int
    let season: String

    func welcome() {
        print("Welcome to the Cohort \(number) of Ed Farm's Pathways, taking place during the \(season) of \(year)!")
    }
}

let currentCohort = Cohort(number: 3, year: 2021, season: "Winter")

currentCohort.welcome()
//: [Previous](@previous) | [Next](@next)
