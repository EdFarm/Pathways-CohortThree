//: ## Common Types
/*:
 - Swift provides many built-in types by default
 - Below we have just a few...
 */

// Integer
let numberOfAnimals = 53

// Double
var priceOfTicket = 12.95

// Boolean
let swiftIsAwesome = true // or false?

// String
let name = "Taylor Smith"
//: [Previous](@previous) | [Next](@next)
