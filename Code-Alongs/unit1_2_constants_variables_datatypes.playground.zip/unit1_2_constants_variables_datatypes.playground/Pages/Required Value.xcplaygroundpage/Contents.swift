//: ## Required Value
/*:
 - More safety: Swift requires a value before you can use a variable or constant!
 */

var firstName: String

// more awesome code here...















// ... now it's time to use firstName...

print(firstName) // how do we fix this?
//: [Previous](@previous) | [Next](@next)
