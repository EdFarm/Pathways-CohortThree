//: ## Type Inference
/*:
- In most cases, Swift is smart enough to know which type we want for our values
 - Sometimes, to clarify ambiguous cases, we want to explicitly annotate our types
*/
// what happens if we remove the annotations?
let numberOfAnimals: Int = 53
var priceOfTicket: Double = 12.95
let swiftIsAwesome: Bool = true
let name: String = "Taylor Smith"
//: [Previous](@previous) | [Next](@next)
