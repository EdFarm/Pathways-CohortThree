//: # Constants & Variables & Data Types (OH MY!)
//: ## Unit 1.2
/*:
 Where do we Begin?
 - Constants
 - Variables
 - Basic Data Types
 */
//: [Constants!](@next)
