import Foundation

struct Car {
    var odometer = 0.0 {
        willSet {
            print("2. About to set odometer to \(newValue)")
        }
        didSet {
            // if invalid (-1000?), revert to oldValue
            print("3. Our odometer's old value was \(oldValue)")
        }
    }
}

var car = Car()
print("1. The car has traveled \(car.odometer) miles.")
car.odometer += 1_000
// willSet
// didSet
print("4. The car's odometer now reads \(car.odometer).")

