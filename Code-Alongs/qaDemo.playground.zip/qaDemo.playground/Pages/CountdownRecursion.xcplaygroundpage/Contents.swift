import Foundation

func countdown(from value: Int) {
    print(value)
    let shouldContinue = value > 0
    if shouldContinue {
        let newValue = value - 1
        // recursion...
        countdown(from: newValue)
    } else {
        print("All done!")
    }
}

var start = 50
countdown(from: start)
