//
//  ViewController.swift
//  VCLifecycleDemo
//
//  Created by Taylor Smith on 3/31/21.
//

import UIKit

class ViewController: UIViewController {
    // first
    override func viewDidLoad() {
        super.viewDidLoad()
        print("View Controller 1 - View Did Load\n")
    }

    // second
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("View Controller 1 - View Will Appear\n")
    }

    // third
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("View Controller 1 - View Did Appear\n")
    }

    // fourth
    override func viewWillDisappear(_ animated: Bool) {
        print("View Controller 1 - View Will Disappear\n")
        super.viewWillDisappear(animated)
    }

    // fifth
    override func viewDidDisappear(_ animated: Bool) {
        print("View Controller 1 - View Did Disappear\n")
        super.viewDidDisappear(animated)
    }
}
