//: ## Order of Operations
//: ### Just like in Math Class!
/*:
- Order from first to last:
  - Operations in parentheses
  - Multiplication and division
  - Addition and subtraction
*/
var order = 2 + 3 * 5
var orderParentheses = (2 + 3) * 5

print(order)
print(orderParentheses)
//: [Previous](@previous) | [Next](@next)
