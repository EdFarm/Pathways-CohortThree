//: ## Compound Assignment
/*:
- Callout(What if...): There was an more succinct way to use a value while reassigning it?
 */
/*:
- Compound assignment allows you to run an operation using a value and reassign that result with less repetition
- Available operators: `+`, `-`, `*` (multiplication), `/` (division)
*/
var currentDisplayedDistance = 12.4
let distanceSincePreviousCheck = 2.3

/*:
 - Callout(Example): What does compound assignment look like?
 */
currentDisplayedDistance -= distanceSincePreviousCheck
print(currentDisplayedDistance)

/*:
 - Callout(Practice): What if we had to backtrack on our driving route, adding mileage to the trip?
 */

//: [Previous](@previous) | [Next](@next)
