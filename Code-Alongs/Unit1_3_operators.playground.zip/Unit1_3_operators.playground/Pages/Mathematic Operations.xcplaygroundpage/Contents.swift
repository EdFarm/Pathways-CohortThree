//: ## Basic Math
/*:
 - One of the most common ways to use operators is when doing basic arithmetic
 - Can use raw values (1, 3, 7.2, e.g.) or use constants/variables you have initialized
 */
/*:
 - Callout(Example): what if we bought 2 items for $7 each?
 */
var totalCost = 2 * 7 // multiplication is done with "*" operator
print(totalCost)
/*:
 - Callout(Practice): How could we calculate the cost per item using `totalCost` and the number of items?
 */

/*:
 - Callout(Practice): Given today's date, how do we calculate tomorrow's date, assuming we don't begin a new month?
 */
var todaysDate = 4

/*:
 - Callout(Practice): Let's figure out how far it is until we finish driving a route. Assume we have a driving app that updates infrequently over a long trip, perhaps to reduce battery use over the hours of driving. Given the `currentDisplayedDistance` and the `distanceSincePreviousCheck` our app should update `currentDisplayedDistance` so our app can display the new distance.
 */
var currentDisplayedDistance = 12.4
let distanceSincePreviousCheck = 2.3

//: [Previous](@previous) | [Next](@next)
