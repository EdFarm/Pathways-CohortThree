//: ## Assigning Values
/*:
 - We've seen this when assigning values to constants and variables
 - "Assigning" a value is another way to say that you are setting that variable or constant to that value
 */
/*:
 - Callout(Operator for assigning values): `=`
 */
let month = "February"

var dayOfTheMonth = 4

print(dayOfTheMonth)
/*:
 - Callout(Practice): Assign a new value to `dayOfTheMonth` below, then print it again.
 */

//: [Previous](@previous) | [Next](@next)

