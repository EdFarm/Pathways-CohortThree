//: ## Removing Items from Arrays
/*:
 */
var names = ["Janet", "Bill", "Rosie"]
names.insert("David", at: 2)
print("Before removing any names:\n\(names)\n")

names.remove(at: 3)
print("After removing index 3:\n\(names)\n")
//: [Previous](@previous) | [Next](@next)
import Foundation
