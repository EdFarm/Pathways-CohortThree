//: ## Setting Array Items
/*:
 */
var myArray = [1, 1, 2, 3, 5, 8, 13, 21]

print("\(myArray) <- Before")

// Use the array index to set a new value at that index
myArray[0] = 0
myArray[3] = 4
myArray[6] = 30

print("\(myArray) <- After")
// should be... [0, 1, 2, 4, 5, 8, 30, 21]
//: [Previous](@previous) | [Next](@next)
import Foundation
