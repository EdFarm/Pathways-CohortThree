//: ## Inserting Items into Arrays
/*:
 */
var names = ["Janet", "Bill", "Rosie"]
print("Before inserting a new name:\n\(names)\n")

names.insert("David", at: 2)
print("Results after insert(at:)\n\(names)")
//: [Previous](@previous) | [Next](@next)


import Foundation
