//: ## Accessing Array Items
/*:
 - Use the `index` of an item and _subscript_ syntax to access it in an array
 - The first item in an array has an index of 0
 */
let myArray = [1, 2, 3, 5, 8, 13, 21]
//array index [0  1  2  3  4  5   6]
print(myArray.count)
print(myArray[0]) // what will this be?
print(myArray[4]) // what will this be?
print(myArray[myArray.count-1]) // myArray[6] -- what will this be?
//: [Previous](@previous) | [Next](@next)


import Foundation
