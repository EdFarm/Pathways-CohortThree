//: ## Arrays
/*:
 - Arrays contain **ordered** collections of items
 - **Type Safety** - All items in the array are expected to be the same type
 - Type can be inferred or annotated as needed

So... How do we instantiate an array?
 */
var intArray: [Int] = []
var stringArray: Array<String> = []
var boolArray = [Bool]()

intArray = [1, 2, 3, 5, 8, 13, 21]

var greeting = "Hello there"
stringArray = [] // fill this with values!
boolArray = [] // fill this with values!

// Swift can also infer our array type
var names = ["Janet", "Bill", "Rosie"]
//: beward the `Any` type...
var anyArray: [Any] = ["hello", 1, 2, 3.4, false] // you no longer have type safety!
//: [Previous](@previous) | [Next](@next)


import Foundation
