//: ## Appending to Arrays
/*:
 - As you need to, you can add, or `append` items to the end of an array
 */
var myArray = [1, 1, 2, 3, 5, 8, 13, 21]
print("Starting place for our array:\n\(myArray)\n")

myArray.append(34) // append instance method
print("After appending a single value:\n\(myArray)\n")

myArray.append(contentsOf: [55, 89]) // appends multiple items
print("After appending `contentsOf: [55, 89]`\n\(myArray)\n")

myArray += [144, 233] // compound operator
print("After compound assignment:\n\(myArray)\n")
//: [Previous](@previous) | [Next](@next)
import Foundation
