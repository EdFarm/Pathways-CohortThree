//: ## Dictionaries
/*:
 - Dictionaries are collections of `key: value` pairs
 - Useful for modeling more complex data without creating new types
 - Unique Keys -- NO duplicate keys in a dictionary
 - Values CAN be duplicated
 - Dictionaries are **unordered**
 */
// notice the various ways to type annotate a dictionary below
var addressList = [String: String]() // ["name": "address"]

var nameNumberDictionary = Dictionary<String, Int>() // ["myName": 5]

var idToNameDictionary: [Int: String] = [:] // [12345: "Your Name Here"]

var anotherDictionary: Dictionary<String, Double> = [:]

// Swift can also infer the types in a dictionary
var contacts = ["Janet": "111-111-1111", "Bill": "222-333-4444", "Rosie": "205-867-5309"]
print(contacts)
//: [Previous](@previous) | [Next](@next)


import Foundation
