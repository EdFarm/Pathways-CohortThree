//: ## Value Methods for Dictionaries
/*:
 - Using `updateValue()` or `removeValue` returns the old value for that key, should you need it
 - These return `nil` if the key does not exist
 */
var contacts = ["Janet": "111-111-1111", "Bill": "222-333-4444", "Rosie": "205-867-5309", "Steve": "ABC123"]

let oldValue: String = contacts.updateValue("999-888-7777", forKey: "Janet")!
print("oldValue = \(oldValue)")

let oldValue2: String = contacts.removeValue(forKey: "Steve")!
print("oldValue2 = \(oldValue2)")
//: [Previous](@previous) | [Next](@next)


import Foundation
