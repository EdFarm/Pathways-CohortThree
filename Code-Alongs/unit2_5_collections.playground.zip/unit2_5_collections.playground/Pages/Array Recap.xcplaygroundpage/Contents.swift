//: ## Array Recap
/*:
 - Arrays are ordered lists of items of the same type, including arrays
 - `["I", "am", "an", "array"]` and `[1, 3, 5, 7, 9]`
 - Like other types, arrays have properties and methods
 - Access items using _subscript_ syntax - `myArray[0]`
 - Modify the array by appending, inserting, and removing items
 */
//: ## Questions?
//: [Previous](@previous) | [Next](@next)
