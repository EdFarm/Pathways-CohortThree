//: ## Dictionary Recap
/*:
 - Dictionaries are unordered collections of key: value pairs
 - Like other types, dictionaries have properties and methods
 - Access values using _subscript_ syntax - `dictionary["key"]`
 - Modify the dictionary by updating, inserting, and removing items
 */
//: ## Questions?
//: [Previous](@previous) | [Next](@next)
