//: ## Removing Dictionary Values
/*:
 - Set the `value` for a `key` to `nil` to remove it
 - Can also use the `removeValue(forKey:)` method
 */
var contacts = ["Janet": "555-666-7777", "Bill": "222-333-4444", "Steve": "12345", "Rosie": "205-867-5309"]
print("Starting place for contacts:\n\(contacts)\n")

contacts["Janet"] = nil // Removing an element by using nil

contacts.removeValue(forKey: "Steve") // method to remove a value

print("After removing \"Janet\" and \"Steve\":\n\(contacts)\n")
//: [Previous](@previous) | [Next](@next)
import Foundation
