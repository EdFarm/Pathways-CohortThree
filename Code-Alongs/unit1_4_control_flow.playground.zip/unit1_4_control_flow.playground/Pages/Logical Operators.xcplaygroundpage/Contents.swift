//: ## Logical Operators
/*:
 - New list of operators, similar to Unit 1.3
 - Compare the left and right values to determine a `true` or `false` (boolean) value.
 */
//: ### Challenge Time!
//: What is the result of the following statements?
/*:
- Callout(Left and right value are equal): ==
*/
1 == 1
1 == 2
/*:
- Callout(Left and right value are not equal): !=
*/
1 != 2
3 != 3
/*:
- Callout(Left value is greater than the right value ): >
*/
1 > 3
3 > 3
8 > 4
/*:
- Callout(Left value is greater than OR equal to the right value ): >=
*/
1 >= 3
3 >= 3
8 >= 4
/*:
- Callout(Left value is less than the right value ): <
*/
1 < 3
3 < 3
8 < 4
/*:
- Callout(Left value is less than or equal to the right value ): <=
*/
1 <= 3
8 <= 4
3 <= 3
/*:
- Callout(Left value AND right value are both TRUE): &&
*/
true && true
false && false
false && true // false prevents running later code
(1 < 3) && (2 >= 2)
/*:
- Callout(Left value OR right value is TRUE): ||
*/
true || true
false || false
true || false
(8 > 4) || (4 < 2)
/*:
- Callout(Returns the opposite of the following statement): !
*/
!true
!false
!(8 < 4)
/*:
 - Callout(Practice): What is the result for each statement below?\
Practice by writing the answer in the comment for each line, then check your answers by running those lines of the playground.
 */
// == (equal) operator
true == true        // Answer:
false == false      // Answer:

// != (not equal) operator
14 + 3 != 19 - 3    // Answer:
false != false      // Answer:

// > (greater than) operator
15 + 5 > 20 - 2     // Answer:
12 - 3 > 10         // Answer:

// >= (greater than or equal) operator
12 >= 12            // Answer:
80 >= 65            // Answer:
41.1 >= 41.2        // Answer:

// < (less than) operator
8 < 9                       // Answer:
21 < 18                     // Answer:
(12 * 4) < 12 * (2 * 2)     // Answer:

// <= (less than or equal) operator
27 <= 24            // Answer:
12 <= 12            // Answer:
41 <= 51            // Answer:

// && (AND) operator
true && false       // Answer:
(1 != 2) && false   // Answer:

// || (OR) operator
false || true                                   // Answer:
false || (100 > 500) || true || false || false  // Answer:

// ! (NOT) operator
!(15 >= 15)         // Answer:
!(!true)            // Answer:

//: [Previous](@previous) | [Next](@next)


import Foundation
