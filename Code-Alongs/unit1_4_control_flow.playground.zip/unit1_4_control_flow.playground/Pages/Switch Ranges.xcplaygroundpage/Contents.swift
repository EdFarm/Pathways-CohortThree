//: ## Switch Ranges
//: ### Need to cover a range?
/*:
- Ranges allow us to cover a long range of numbers in one case with clean syntax
- `1...9` includes both numbers on the ends ("inclusive")
- `1..<9` does not include the right end value ("not inclusive")
- Ranges can also be used elsewhere, like `for` loops
*/

let peopleInZoom = 35
let almostNobody = 1...9
switch(peopleInZoom) {
case almostNobody:
  print("At least a few are here!")
case 10...20:
  print("The headcount has two digits!")
case 21...30:
  print("Most of the class is here!")
case 31..<32:
  print("Almost everybody's here!")
case 32:
  print("YOU'RE ALL HERE!!")
case 0:
  print("Where'd everybody go?")
default:
  print("I have no clue how many to expect")
}

/*:
 - Callout(Practice): Try putting the range values into constants before the switch statement.\
Does that make the different values easier to find or modify, should you need to?
 */

//: [Previous](@previous) | [Next](@next)
