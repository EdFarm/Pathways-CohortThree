//: ## Booleans
/*:
 - `Booleans` are one of the data types we introduced briefly in unit 1.2
 - Boolean values are either true or false
 - 'Bool' is the type annotation used for boolean values
 */
let myBool: Bool = true // notice the type annotation here

var isTuesday = true

var isSwiftNight = true

var isAlmostTheWeekend = false
//: [Previous](@previous) | [Next](@next)
import Foundation
