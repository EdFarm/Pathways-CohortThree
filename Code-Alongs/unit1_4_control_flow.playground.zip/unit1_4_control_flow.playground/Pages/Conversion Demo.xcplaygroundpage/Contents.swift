//: ## Demo Time!
/*:
 - Callout(What If...): We wanted to convert this from an if-else to a switch?
 */
let temperature = -10

if temperature > 32 && temperature < 212 {
  print("It's water!")
} else if temperature <= 32 {
  print("It's ice!")
} else {
  print("It's steam!")
}


/*:
 - Callout(Challenge): Can we clarify/simplify our code by putting our values into constants? How might that work?
 */

//: [Previous](@previous) | [Next](@next)


import Foundation
