//: ## `if` Statements
/*:
 - Simplest conditional statement
 - "if this is true, then... do that"
 */
/*:
 `if` statement syntax

     if true {
        do a thing
        // run some code
     }
 */
let dayOfTheWeek = "Tuesday"

let isTuesday = dayOfTheWeek == "Tuesday"
let isThursday = dayOfTheWeek == "Thursday"

if isTuesday || isThursday {
  print("Let's learn Swift tonight!")
}
//: [Previous](@previous) | [Next](@next)
