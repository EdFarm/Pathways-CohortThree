//: ## else-if Statements
/*:
- A third way to structure `if` statements
 - Allows for multiple additional blocks of code, each with a conditional statement to check
 */
/*:
 `else-if` syntax

     if true { // if condition is true
       // do this...
     } else if true {
       // do another thing...
     } else if true {
       // do yet another thing... and so on...
     } else {
       // do that...
     }
 */
/*:
- Callout(What If...): We want to print out a message on different days of the week?\
 If it's Tuesday between 5 PM and 8 PM (roughly!), print "Let's learn Swift tonight!".\
 If it's Thursday, print "Almost the weekend but let's learn some Swift!".\
 If it's Friday after 5 PM, or Saturday or Sunday, print "Have a great weekend!".\
 Otherwise print "Relax, no class tonight!".
*/
let dayOfTheWeek = "Tuesday"
let hourOfTheDay = 18
/*:
 - Callout(Practice): Change `dayOfTheWeek` and `hourOfTheDay` to display different messages, or set up your own if-else control flow to display different messages!
 */
//: [Previous](@previous) | [Next](@next)
