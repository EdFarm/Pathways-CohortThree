//: ## Ternary Operator
//: ### Useful for simple conditionals
/*:
 - Sometimes all we have is a small conditional
 - Ternary statements are shorthand that can reduce the code we have to write
 - Not always the simplest syntax to read, so use cautiously
 */
var message: String

let installedVersion = 13.7
let currentVersion = 14.0

if installedVersion >= currentVersion {
  message = "Thank you for installing the latest version!"
} else {
  message = "Please install the latest version."
}

print(message)
/*:
 `ternary` statement syntax

    result = conditional ? true : false
 */
/*:
 - Callout(What If...): we wanted to write a statement that produces the same result as the `if-else` statement above?
 */


print(message)
//: [Previous](@previous) | [Next](@next)



import Foundation
