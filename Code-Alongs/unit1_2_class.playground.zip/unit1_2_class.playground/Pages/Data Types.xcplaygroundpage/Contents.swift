//: ## Types
//: ### Data and Behavior Combined
struct Cohort {
  let year: Int
  let season: String

  func welcome() {
    print("Welcome to the \(season) \(year) cohort of EdFarm's Pathways Program!")
  }
}

let cohort2 = Cohort(year: 2020, season: "Fall")

cohort2.welcome()
//: [Previous](@previous) | [Next](@next)
