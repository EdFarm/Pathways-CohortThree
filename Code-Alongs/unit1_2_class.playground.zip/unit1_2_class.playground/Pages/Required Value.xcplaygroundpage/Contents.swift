//: ## Required Value
/*:
 - More safety: Swift requires a value before you can use a variable or constant!
 */

var firstName: String

// whatever other code here...















firstName = "Taylor"

// more awesome code in between...

print(firstName) // how do we fix this?
//: [Previous](@previous) | [Next](@next)
