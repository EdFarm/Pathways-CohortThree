//: ## Comments
/*:
 - Comments let us make notes in our code or hide things from the compiler
 - Good comments can help make code more easy to understand for the next person who reads our code!
 - Remember: you *may* be the next person who reads your code, and may need help understanding it then!
 */
// I'm a single line comment!
// This is another comment

/*
 I'm a long comment
 with multiple lines
*/

// hey look I've got a comment! Hope this helps!

// I'm a variable! Change me!
// maybe this name isn't as descriptive as it could be...
var anotherVar = "Comment Me" // hey I'm a comment too!
//: [Previous](@previous) | [Next](@next)
