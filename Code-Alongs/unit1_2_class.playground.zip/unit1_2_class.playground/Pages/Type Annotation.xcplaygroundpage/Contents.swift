//: ## Type Annotation
/*:
- We can explicitly label our values with their type
 - Syntax is `name: Type` as shown below
 - Typically not required!
 */
var numberOfEmployees: Int = 13

var priceOfCoffee: Double = 2.75

var swiftIsAwesome: Bool = true

var firstName: String = "Taylor"
//: [Previous](@previous) | [Next](@next)
