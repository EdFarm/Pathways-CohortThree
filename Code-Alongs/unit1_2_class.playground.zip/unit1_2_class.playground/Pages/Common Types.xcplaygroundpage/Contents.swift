//: ## Common Types
/*:
 - Swift provides many built-in types by default
 - Below we have just a few...
 */

// Integer
let numberOfEmployees = 13

// Double
var priceOfCoffee = 2.75

// Boolean
let swiftIsAwesome = true // or false?

// String
let name = "Taylor Smith"
//: [Previous](@previous) | [Next](@next)
