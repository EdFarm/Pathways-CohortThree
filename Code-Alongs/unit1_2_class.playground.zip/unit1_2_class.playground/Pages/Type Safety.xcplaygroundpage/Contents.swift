//: ## Type Safety
/*:
 - Once the type of an instance is set in Swift, it cannot be changed
 */
var numberOfEmployees = 13 // I'm an Integer

var priceOfCoffee = 2.75 // I'm a Double

var swiftIsAwesome = true

var firstName = "Taylor"

numberOfEmployees = "hello"

priceOfCoffee = numberOfEmployees
//: [Previous](@previous) | [Next](@next)
