//: ## Constants
/*:
 - Constants CANNOT be changed after being initialized.
 - Read aloud as "let firstName equal Taylor"
 */
/*:
 - Callout(Keyword!): `let`
 */
let firstName = "Smith"
let cohort = 2
let currentYear = 2020
let meetingInPerson = false

let anotherFirstName = "Steve"

print(firstName)
//: [Previous](@previous) | [Next](@next)


import Foundation
