//: ## Group Discussion
//: ### When should you use constants or variables?
/*:
- We're going to build an app for a doughnut shop to handle deliveries.
 - They make one product, the **"Box of Awesome"** with 13 amazing doughnuts.
 - What data do we need for them to handle orders?
 - What should be constant and what should be variable?
*/
// variables and constants go HERE

// customer data
let customerName = "Customer"
let customerAddress = "123 Main Street"
let ccInfo = 1234567890

// related to the business
let costOfBox = 13.50
var availableBoxes = 45

// order information
// order statuses: Received, Prep, Cooking, Quality Check, In Transit, Delivered
var orderStatus = "Prep" // may have different statuses for order
var currentLocation = 123
var estimatedTimeOfArrival = 30
let numberOfBoxes = 3

print(orderStatus)

// time passes, doughnuts get delivered
// delivery person marks order delivered
orderStatus = "Delivered"

print(orderStatus)
//: [Previous](@previous) | [Next](@next)


import Foundation
