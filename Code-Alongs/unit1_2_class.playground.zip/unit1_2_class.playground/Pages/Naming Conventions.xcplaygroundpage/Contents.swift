//: ## Naming Rules and Best Practices
/*:
- No mathematical symbols or spaces
 - Can't begin with a number
- Use meaningful names
- "Camel case" should be used to join multiple words
 */
var y = 2020 // I think y is the year, but...
var year = 2020 // that's not so hard, right?

let fn = "Taylor" // what does fn mean?
let firstName = "Taylor" // much better!

let 🤖 = "SwiftBot" // even emoji are allowed!

// uncomment below for broken examples
//let 1problemHere = 1 // can't begin with a number!
//let x+y = 2 // can't use mathematical symbols

let x = 1
let xPlusY = x + y
//: [Previous](@previous) | [Next](@next)
