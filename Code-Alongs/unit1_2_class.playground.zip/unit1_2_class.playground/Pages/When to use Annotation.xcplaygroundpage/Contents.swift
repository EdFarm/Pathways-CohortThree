//: ## When is annotation useful?
//: ### A few cases
// when you haven't assigned a value yet
let firstName: String

// when you need to clarify type ambiguity
// numberOfEmployees inferred to be an Integer
// type annotation clarifies ambiguity
var numberOfEmployees: Double = 13
var priceOfCoffee = 2.75
let coffeeBudget = numberOfEmployees * priceOfCoffee

// when adding properties to a type definition
struct Cohort {
  let year: Int
  let season: String

  func welcome() {
    print("Welcome to the \(season) \(year) cohort of EdFarm's Pathways Program!")
  }
}
//: [Previous](@previous) | [Next](@next)
