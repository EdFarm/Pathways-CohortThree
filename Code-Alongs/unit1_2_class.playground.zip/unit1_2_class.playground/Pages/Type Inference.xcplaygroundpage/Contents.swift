//: ## Type Inference
/*:
- In most cases, Swift is smart enough to know which type we want for our values
 - Sometimes, to clarify ambiguous cases, we want to explicitly annotate our types
 */
var numberOfEmployees = 13
var priceOfCoffee = 2.75
let swiftIsAwesome = true
var firstName = "Taylor"
//: [Previous](@previous) | [Next](@next)
