import UIKit
import PlaygroundSupport
// data URL = https://zoo.tiki.dev/index.json
// use this to allow for long running tasks
PlaygroundPage.current.needsIndefiniteExecution = true
//: Constructing a URL the long way...
let webProtocol = "https"
let subdomain = "zoo"
let domain = "tiki.dev"
let path = "index.json"

let fullURL = "\(webProtocol)://\(subdomain).\(domain)/\(path)"

//let url = URL(string: fullURL)!
//: OR...
let baseURL = "https://zoo.tiki.dev"
let url = URL(string: "\(baseURL)/index.json")!
//: Let's use the URL to make a request below...
let request = URLSession.shared.dataTask(with: url) { (data, response, error) in
    let jsonDecoder = JSONDecoder()
    if let data = data,
       let dataString = String(data: data, encoding: .utf8),
       let animals = try? jsonDecoder.decode([Animal].self, from: data) {
        // send notification with animal info...
        print(dataString)
        for animal in animals {
            print(animal)
        }
    }
    // handle the error...
    // use response values for other requests...

    PlaygroundPage.current.finishExecution()
}

request.resume()
