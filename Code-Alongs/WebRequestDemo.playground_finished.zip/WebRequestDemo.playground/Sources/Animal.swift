import Foundation

public struct Animal: CustomStringConvertible, Codable {
    public var name: String
    public var species: String
    public var height: Double
    public var weight: Double
    public var area: String
    public var facts: String
    public var image: String

    public var description: String {
        return "\(name) is a \(species)\nHeight: \(height) m, Weight: \(weight) kg\nArea: \(area)\nFun Facts: \(facts)\nImage: \(image).\n\n"
    }

    public enum CodingKeys: String, CodingKey {
        case name, species, height
        case weight
        case area
        case facts = "funFacts" // note the difference between the string and enum case
        case image = "image_url"
    }
}
