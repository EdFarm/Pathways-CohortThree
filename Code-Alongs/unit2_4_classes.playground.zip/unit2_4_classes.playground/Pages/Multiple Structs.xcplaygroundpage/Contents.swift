import Foundation
//: # Multiple Structs
/*:
 - We *could* use multiple structs to represent different animal types
 */
struct Mammal {
    // basic properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters

    func constructDetails() -> String {
        var results = "All about \(name), the \(species)\n\n"
        results += "Description: \(description)\n\n"
        results += "Sizes:\n"
        results += "\tHeight: \(height) meters\n"
        results += "\tWeight: \(weight) kilograms\n"
        return results
    }
}

struct Reptile {
    // basic properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters

    func constructDetails() -> String {
        var results = "All about \(name), the \(species)\n\n"
        results += "Description: \(description)\n\n"
        results += "Sizes:\n"
        results += "\tHeight: \(height) meters\n"
        results += "\tWeight: \(weight) kilograms\n"
        return results
    }
}

struct Bird {
    // basic properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters

    var canFly: Bool = true // hey look a property just for birds!

    func constructDetails() -> String {
        var results = "All about \(name), the \(species)\n\n"
        results += "Description: \(description)\n\n"
        results += "Sizes:\n"
        results += "\tHeight: \(height) meters\n"
        results += "\tWeight: \(weight) kilograms\n"
        return results
    }
}

struct Fish {
    // basic properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters

    var swimmingSpeed: Double // km / hour

    func constructDetails() -> String {
        var results = "All about \(name), the \(species)\n\n"
        results += "Description: \(description)\n\n"
        results += "Sizes:\n"
        results += "\tHeight: \(height) meters\n"
        results += "\tWeight: \(weight) kilograms\n"
        return results
    }
}

struct Amphibians {
    // basic properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters

    func constructDetails() -> String {
        var results = "All about \(name), the \(species)\n\n"
        results += "Description: \(description)\n\n"
        results += "Sizes:\n"
        results += "\tHeight: \(height) meters\n"
        results += "\tWeight: \(weight) kilograms\n"
        return results
    }
}
//: [Previous](@previous) | [Next](@next)
