import Foundation
//: # Inheritance
/*:
 - The SUPER POWER of classes
 - Allows us to build complex hierarchies of types
 - Top level class is a base (or super) class
 - Properties and methods are passed down to subclasses
 */
class Animal {
    // basic properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters

    init(name: String, species: String, description: String, weight: Double, height: Double) {
        self.name = name
        self.species = species
        self.description = description
        self.weight = weight
        self.height = height
    }

    func constructDetails() -> String {
        var results = "All about \(name), the \(species)\n\n"
        results += "Description: \(description)\n\n"
        results += "Sizes:\n"
        results += "\tHeight: \(height) meters\n"
        results += "\tWeight: \(weight) kilograms\n"
        return results
    }
}
//: ----
//: ## Subclasses of Animal below
//: Notice the `: Animal` syntax below?
//:
//: That's indicating inheritance!
class Mammal: Animal {
}

class Reptile: Animal {
}

class Amphibian: Animal {
}
//: When we add properties, we have to provide a subclass initializer
class Bird: Animal {
    var canFly: Bool = true

    init(name: String, species: String, description: String, weight: Double, height: Double, canFly: Bool = true) {
        self.canFly = canFly
        // use `super` here to refer to the base class
        super.init(name: name, species: species, description: description, weight: weight, height: height)
    }
}

class Fish: Animal {
    var swimmingSpeed: Double // km / hour

    init(name: String, species: String, description: String, weight: Double, height: Double, swimmingSpeed: Double) {
        self.swimmingSpeed = swimmingSpeed
        super.init(name: name, species: species, description: description, weight: weight, height: height)
    }
}
//: ---
//: We can go even further down into our hierarchy
class Cat: Mammal {
}

class Cheetah: Cat {
}

class Elephant: Mammal {
}

class Eagle: Bird {
}
//: ---
//: Hierarchy "map" from above code
// Animal

// Animal > Mammal
// Animal > Mammal > Cat
// Animal > Mammal > Cat > Cheetah
// Animal > Mammal > Elephant

// Animal > Reptile

// Animal > Amphibian

// Animal > Bird
// Animal > Bird > Eagle

// Animal > Fish

//: Let's instantiate a few of our animals!
let duma = Cheetah(name: "Duma", species: "Cheetah", description: "Cheetahs are the fastest land animal.", weight: 60, height: 1.5)

let ollie = Bird(name: "Ollie", species: "Ostrich", description: "Ostriches can tolerate a wide range of extreme temperatures.", weight: 100, height: 2.3, canFly: false)
//: [Previous](@previous) | [Next](@next)
