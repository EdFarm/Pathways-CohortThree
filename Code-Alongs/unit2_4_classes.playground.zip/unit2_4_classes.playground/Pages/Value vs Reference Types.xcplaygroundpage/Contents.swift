import Foundation
//: # Value vs Reference Types
/*:
 - There are two key ways Swift manages the memory for the objects created in code.
 - Value types are copied between instances
 - Reference types refer to a point in memory that is shared between instances
 - Structs are value types, Classes are reference types

What does that look like when we make changes to our types?
 */
struct User {
    var name: String
    var email: String
    var password: String

    var details: String {
        return "Name: \(name)\nEmail: \(email)\nPassword:\(password)\n"
    }
}

var user1 = User(name: "User1", email: "test@example.com", password: "testTestTest")
var user2 = user1
print("User1 DETAILS BEFORE\n\(user1.details)")
print("User2 DETAILS BEFORE\n\(user2.details)")
user2.name = "User2"
user2.email = "user2@example.com"
print("User1 DETAILS AFTER\n\(user1.details)")
print("User2 DETAILS AFTER\n\(user2.details)")
//: ---
class Animal {
    var name: String
    var species: String
    var description: String

    init(name: String, species: String, description: String) {
        self.name = name
        self.species = species
        self.description = description
    }

    var details: String {
        return "Name: \(name)\nSpecies: \(species)\nDescription:\(description)\n"
    }
}

var elephant1 = Animal(name: "Tantor", species: "African Elephant", description: "Elephants are the largest land animal.")
var elephant2 = elephant1
print("Elephant1 DETAILS BEFORE\n\(elephant1.details)")
print("Elephant2 DETAILS BEFORE\n\(elephant2.details)")
elephant2.name = "Dumbo"
print("Elephant1 DETAILS AFTER\n\(elephant1.details)")
print("Elephant2 DETAILS AFTER\n\(elephant2.details)")

