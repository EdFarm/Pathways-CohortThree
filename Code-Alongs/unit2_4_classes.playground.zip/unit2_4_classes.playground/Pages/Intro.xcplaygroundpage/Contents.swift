//: # Classes and Inheritance
//: ## Unit 2.3
/*:
 - More custom types!
 - How do we define a class?
 - Inheritance
 - Overriding
 - Value Types and Reference Types
 - Structs or Classes?
 */
//: [Next](@next)
