import Foundation
//: # Let's start with a Struct
/*:
 - A simplified version of our Animal Struct
 - Taking advantage of our memberwise initializer

What if we wanted to convert this to a class?
 */
struct Animal {
    // basic properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters

    func constructDetails() -> String {
        var details = "All about \(name), the \(species)\n\n"
        details += "Description: \(description)\n\n"
        details += "Sizes:\n"
        details += "\tHeight: \(height) meters\n"
        details += "\tWeight: \(weight) kilograms\n"
        return details
    }
}
//: [Previous](@previous) | [Next](@next)
