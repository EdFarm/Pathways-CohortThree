//: # Structs or Classes?
/*:
 - START WITH STRUCTS when defining your own types. It's easy to change a struct into a class if you need to.

  ### When would you need a class, then?

 - If your data fits well with inheritance, absolutely use classes. This may be something you discover as you are working, but don't be afraid to change from structs to classes when you see the benefits of inheritance.

 - If you need a reference type that will point to the same place in memory, use classes. This way, updates to that object can be reflected throughout your app.

 - Since UIKit was around before Swift, and Objective-C didn't have struct, so UIKit is based on classes. When building out your app, there will be times when you'll need to subclass a UIKit class, so you'll have to start with a class there.

 - The most obvious case is the need to subclass the ViewController base class to connect your work in interface builder to view controllers.
 */
