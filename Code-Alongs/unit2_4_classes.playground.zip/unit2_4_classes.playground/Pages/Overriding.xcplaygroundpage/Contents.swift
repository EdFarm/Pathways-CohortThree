import Foundation
//: # Overriding
/*:
 - What if we wanted to use the same method names, but with new behavior?
 - Overriding allows us to change behavior in a subclass, and for all of that classes subclasses
 - Customized behavior when and (only!) where we need it!
 */
class Animal {
    // basic properties
    var name: String
    var species: String
    var description: String

    // size properties
    var weight: Double // kilograms
    var height: Double // meters

    init(name: String, species: String, description: String, weight: Double, height: Double) {
        self.name = name
        self.species = species
        self.description = description
        self.weight = weight
        self.height = height
    }

    func constructDetails() -> String {
        var results = "All about \(name), the \(species)\n\n"
        results += "Description: \(description)\n\n"
        results += "Sizes:\n"
        results += "\tHeight: \(height) meters\n"
        results += "\tWeight: \(weight) kilograms\n"
        return results
    }
}
//: ----
//: ## Subclasses of Animal below
//: Notice the `: Animal` syntax below?
//:
//: That's indicating inheritance!
class Mammal: Animal {
    override func constructDetails() -> String {
        var base = super.constructDetails()
        base += "We love our cute, fuzzy mammal friends!\n"
        return base
    }
}

class Bird: Animal {
    var canFly: Bool = true

    init(name: String, species: String, description: String, weight: Double, height: Double, canFly: Bool = true) {
        self.canFly = canFly
        // use `super` here to refer to the base class
        super.init(name: name, species: species, description: description, weight: weight, height: height)
    }

    override func constructDetails() -> String {
        var details = super.constructDetails()
        if !canFly {
            details += "Though \(name) the \(species) is a bird, they are unable to fly.\n"
        }
        return details
    }
}

let duma = Mammal(name: "Duma", species: "Cheetah", description: "Cheetahs are the fastest land animal.", weight: 60, height: 1.5)
print(duma.constructDetails())

// print a separator
print("=============\n")

let ollie = Bird(name: "Ollie", species: "Ostrich", description: "Ostriches can tolerate a wide range of extreme temperatures.", weight: 100, height: 2.3, canFly: false)
print(ollie.constructDetails())
//: [Previous](@previous) | [Next](@next)
