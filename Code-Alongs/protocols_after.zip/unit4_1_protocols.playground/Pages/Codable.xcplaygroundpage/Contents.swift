import Foundation
//: ## Codable
/*:
 - Useful for encoding/decoding data
 - JSON is most common format - used in web communications
 - Most standard types conform to Codable
 - Any type that conforms to Codable can be used by another Codable
 - We'll see this more when we discuss handling web requests
 */
struct Area: Codable {
    var name: String
}

struct Animal: CustomStringConvertible, Codable {
    var name: String
    var species: String
    var height: Double
    var weight: Double
    var area: Area

    var description: String {
        return "\(name) Details\nSpecies: \(species)\nHeight: \(height)\nWeight: \(weight)"
    }
}

let pascal = Animal(name: "Pascal", species: "Chameleon", height: 0.2, weight: 1 , area: Area(name: "Jungle"))
//: Time to Encode to JSON
let jsonEncoder = JSONEncoder()

if let jsonData = try? jsonEncoder.encode(pascal),
   let jsonString = String(data: jsonData, encoding: .utf8) {
    print(jsonString)
}

let chameleonJSON = """
{
"species": "Chameleon",
"weight": 1,
"name": "Pascal",
"height": 0.20000000000000001,
"area": { "area_name": "Jungle" }
}
"""
//: [Previous](@previous) | [Next](@next)
