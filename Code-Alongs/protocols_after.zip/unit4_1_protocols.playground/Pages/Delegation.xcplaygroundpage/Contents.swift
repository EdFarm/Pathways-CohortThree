import Foundation
//: ## Delegation
/*:
 - Common coding pattern in iOS frameworks like UIKit.
 - An instance of one type calling on an instance of another type to do work for it.
 - Responsibilities get handed off (or "delegated") to other types.
 - Protocols allow flexibility in becoming a delegate.
 - We've seen AppDelegate a lot already.
 - We'll see at least one more delegate soon with UITableView.
 */
