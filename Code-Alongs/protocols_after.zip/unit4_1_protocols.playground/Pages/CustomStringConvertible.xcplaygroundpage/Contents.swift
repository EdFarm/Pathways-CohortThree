import Foundation
//: ## CustomStringConvertible
/*:
 - Use `print()` with cleaner results!
 */
struct Animal: CustomStringConvertible  {
    var description: String {
        return "\(name) is a \(species), weighing \(weight) kg and standing \(height) m tall."
    }

    var name: String
    var species: String
    var height: Double
    var weight: Double
}

let duma = Animal(name: "Duma", species: "Cheetah", height: 1.4, weight: 75)

//print(duma)

print("Information about the animal: \(duma)")
//: [Previous](@previous) | [Next](@next)
