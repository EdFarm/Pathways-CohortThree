import Foundation
//: ## Comparable
/*:
 - Allows us to sort our custom types
 - Specify custom sorting rules based on our needs
 */
struct Animal: CustomStringConvertible, Comparable {
    static func < (lhs: Animal, rhs: Animal) -> Bool {
        return lhs.species < rhs.species
    }

    var name: String
    var species: String
    var height: Double
    var weight: Double

    var description: String {
        return "\(name) Details\nSpecies: \(species)\nHeight: \(height)\nWeight: \(weight)"
    }
}

let pascal = Animal(name: "Pascal", species: "Chameleon", height: 0.2, weight: 1)
let duma = Animal(name: "Duma", species: "Cheetah", height: 1.4, weight: 75)
let tantor = Animal(name: "Tantor", species: "Elephant", height: 3.3, weight: 5500)

var animals = [tantor, pascal, duma]

// maybe we could sort it?

for animal in animals {
    print(animal)
    print("\n")
}

animals.sort()

print("sorted animals:")
for animal in animals {
    print(animal)
    print("\n")
}
//: [Previous](@previous) | [Next](@next)
