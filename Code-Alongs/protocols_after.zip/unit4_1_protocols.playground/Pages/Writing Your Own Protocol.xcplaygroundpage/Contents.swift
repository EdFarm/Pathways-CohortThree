import Foundation
//: # Writing Protocols
//: Our own protocol!
protocol EggLaying {
    var numberOfEggs: Int { get set }

    func countEggs()
}
//: Setup...
class Animal: CustomStringConvertible {
    var name: String
    var species: String
    var height: Double
    var weight: Double

    var description: String {
        return "\(name) Details\nSpecies: \(species)\nHeight: \(height)\nWeight: \(weight)"
    }

    init(name: String, species: String, height: Double, weight: Double) {
        self.name = name
        self.species = species
        self.height = height
        self.weight = weight
    }
}

class Mammal: Animal {
    // imagine mammal features...
}

class Giraffe: Mammal {
    // imagine a giraffe...
}
//: Time to adopt our protocol!
class Platypus: Mammal, EggLaying {
    var numberOfEggs: Int

    func countEggs() {
        print("The \(species) lays \(numberOfEggs) eggs.")
    }

    init(name: String, species: String, height: Double, weight: Double, numberOfEggs: Int) {
        self.numberOfEggs = numberOfEggs
        super.init(name: name, species: species, height: height, weight: weight)
    }
}
//: Adopting Elsewhere
class Bird: Animal, EggLaying {
    var numberOfEggs: Int

    func countEggs() {
        print("The \(species) lays \(numberOfEggs) eggs.")
    }

    init(name: String, species: String, height: Double, weight: Double, numberOfEggs: Int) {
        self.numberOfEggs = numberOfEggs
        super.init(name: name, species: species, height: height, weight: weight)
    }
}

class Parrot: Bird {

}
//: [Previous](@previous) | [Next](@next)
