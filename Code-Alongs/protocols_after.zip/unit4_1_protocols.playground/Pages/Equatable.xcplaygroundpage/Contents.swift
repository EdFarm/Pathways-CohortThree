import Foundation
//: ## Equatable
/*:
 - Allows us to compare two instances of our types
 - Custom rules for comparison based on our data
 */
struct Animal: Equatable {
    var name: String
    var species: String
    var height: Double
    var weight: Double

    static func == (lhs: Animal, rhs: Animal) -> Bool {
        return lhs.name == rhs.name &&
            lhs.species == rhs.species &&
            lhs.height == rhs.height &&
            lhs.weight == rhs.weight
    }
}

let pascal1 = Animal(name: "Pascal", species: "Chameleon", height: 0.2, weight: 1)
let pascal2 = Animal(name: "Pascal", species: "Chameleon", height: 0.2, weight: 1)
let duma = Animal(name: "Duma", species: "Cheetah", height: 1.4, weight: 75)

let areTwins = pascal1 == pascal2
let anotherCheck = pascal2 == duma
//: [Previous](@previous) | [Next](@next)
